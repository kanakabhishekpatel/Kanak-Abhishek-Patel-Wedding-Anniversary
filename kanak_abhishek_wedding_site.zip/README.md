Kanak & Abhishek — Wedding Website
-----------------------------------

What this ZIP contains:
- index.html        -> The full website HTML (edit this to change content, images, date, email)
- /images/          -> Placeholder images (replace with real photos)
- /audio/           -> Put your background audio file here as song.mp3
- README.md         -> (this file) instructions

How to publish on GitHub Pages (simple):
1. Create a GitHub account (if you don't have one).
2. Create a new repository named: <your-username>.github.io
   - Mark it Public.
3. Upload all files from this ZIP to the repository root (index.html at root).
   - You can drag & drop on GitHub web UI or use Git locally.
4. Wait a minute; your site will be live at:
   https://<your-username>.github.io
5. To receive RSVPs by email, edit index.html and replace the 'your-email@example.com' with your real email.
6. To change the wedding date, edit the 'weddingDate' variable in index.html (search for weddingDate).
7. To use Google Maps embed for your actual venue:
   - Open Google Maps, search your venue, click 'Share' -> 'Embed a map' -> copy the iframe code.
   - Replace the iframe in index.html (search for the iframe with src="https://www.google.com/maps?q=India&output=embed").

Optional enhancements:
- Use Formspree or Netlify Forms to collect RSVPs without opening email client.
- Replace placeholder images in /images/ with real photos (same file names or update index.html).
- For autoplay audio on some browsers, user interaction may be required due to browser policies.

Need help?
- Tell me your GitHub username and I can give exact commands to push via Git.
- I can also generate a repo README with deployment commands if you want.

